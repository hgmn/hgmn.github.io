# tests webstar_cleanup.R
# compare treatment effects to Krueger (1999) 
# "Experimental Estimates Of Education Production Functions" 
# The Quarterly Journal of Economics, vol. 114(2), pages 497-532

outlink <- "webstar_clean.csv"

d <- read.csv(outlink)

# some mean and quantile regressions to test

# regressions, compare to Krueger (1999)
f0 <- lm(pscore ~ small + regaide, data = d)
summary(f0)

f1 <- lm(pscore ~ small + regaide + as.factor(fe), data = d)
summary(f1)

f2 <- lm(pscore ~ small + regaide + black + girl + poor + as.factor(fe), data = d)
summary(f2)

f3 <- lm(pscore ~ small + regaide + black + girl + poor + tblack + texp + tmasters + as.factor(fe), data = d)
summary(f3)

# redo regressions as quantile regressions
require(quantreg)
taus <- c(0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95)

g0 <- rq(pscore ~ small + regaide, tau = taus, data = d)
plot(summary(g0), parm = c("small","regaide"))

g1 <- rq(pscore ~ small + regaide + as.factor(fe), tau = taus, data = d)
plot(summary(g1), parm = c("small","regaide"))

g2 <- rq(pscore ~ small + regaide + black + girl + poor + as.factor(fe), tau = taus, data = d)
plot(summary(g2), parm = c("small","regaide"))

g3 <- rq(pscore ~ small + regaide + black + girl + poor + tblack + texp + tmasters + as.factor(fe), tau = taus, data = d)
plot(summary(g3), parm = c("small", "regaide", "black", "girl", "poor", "tblack", "texp", "tmasters"))
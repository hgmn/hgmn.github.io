# Example: Public Project STAR data ("webstar.txt")
# takes webstar.txt, cleans it, and turns it into webstar_clean.cvs.
# 317 classes are uniquely identified using Bryan Graham's ("BSG") method used in
# "Identifying social interactions through conditional variance restrictions" 
# Econometrica 76 (3): 643-660, 2008 
# details can be found at http://goo.gl/UWEjnF

link <- "webstar.txt"
outlink <- "webstar_clean.csv"

d <- read.delim(link)

# set missing values to NA
d$TREADSSK[d$TREADSSK == 999] <- NA
d$TMATHSSK[d$TMATHSSK == 999] <- NA
d$CLTYPEK[d$CLTYPEK == 9] <- NA
d$TOTEXPK[d$TOTEXPK == 99] <- NA
d$HDEGK[d$HDEGK == 9] <- NA
d$SCHIDKN[d$SCHIDKN == 999] <- NA
d$SSEX[d$SSEX == 9] <- NA
d$SRACE[d$SRACE == 9] <- NA
d$SESK[d$SESK == 9] <- NA
d$SES1[d$SES1 == 9] <- NA
d$SES2[d$SES2 == 9] <- NA
d$SES3[d$SES3 == 9] <- NA
d$STARK[d$STARK == 9] <- NA
d$TRACEK[d$TRACEK == 9] <- NA

# impute missing individual-level variables using BSG's algorithm
# use his variable names
black <- as.numeric(d$SRACE == 2)
girl <- as.numeric(d$SSEX == 2)
poor <- as.numeric(d$SESK == 1)
schidkn <- d$SCHIDKN
# use nearest measure of SES if SES is missing
poor[is.na(poor) & d$SES1 == 1 & d$STARK == 1] <- 1
poor[is.na(poor) & d$SES1 == 2 & d$STARK == 1] <- 0
poor[is.na(poor) & d$SES2 == 1 & d$STARK == 1] <- 1
poor[is.na(poor) & d$SES2 == 2 & d$STARK == 1] <- 0
poor[is.na(poor) & d$SES3 == 1 & d$STARK == 1] <- 1
poor[is.na(poor) & d$SES3 == 2 & d$STARK == 1] <- 0
# replace NA by school median (3 black and 7 lunch)
#d[is.na(black) & !is.na(schidkn), ]
#d[is.na(poor) & !is.na(schidkn), ]
black[3364] <- median(black[schidkn == schidkn[3364]], na.rm = TRUE)
black[7086] <- median(black[schidkn == schidkn[7086]], na.rm = TRUE)
black[7899] <- median(black[schidkn == schidkn[7899]], na.rm = TRUE)
poor[1348] <- median(poor[schidkn == schidkn[1348]], na.rm = TRUE)
poor[5809] <- median(poor[schidkn == schidkn[5809]], na.rm = TRUE)
poor[7086] <- median(poor[schidkn == schidkn[7086]], na.rm = TRUE)
poor[7899] <- median(poor[schidkn == schidkn[7899]], na.rm = TRUE)
poor[8093] <- median(poor[schidkn == schidkn[8093]], na.rm = TRUE)
poor[9012] <- median(poor[schidkn == schidkn[9012]], na.rm = TRUE)
poor[9693] <- median(poor[schidkn == schidkn[9693]], na.rm = TRUE)

# kindergarten teacher characteristics
# BSG's variable names
blackteacherK <- as.numeric(d$TRACEK == 2)
mastersK <- as.numeric(d$HDEGK > 2)
experienceK <- d$TOTEXPK
#experience_sqK = experienceK^2
smallK <- as.numeric(d$CLTYPEK == 1)
regaideK <- as.numeric(d$CLTYPEK == 3)  # BSG uses 2?

# unique assignments found by BSG
blackteacherK[d$NEWID==81622] <- 0 
blackteacherK[d$NEWID==94070] <- 0 
blackteacherK[d$NEWID==145326] <- 1 
blackteacherK[d$NEWID==82283] <- 1 
blackteacherK[d$NEWID==156231] <- 1 
blackteacherK[d$NEWID==170397] <- 1 
blackteacherK[d$NEWID==125369] <- 1 
blackteacherK[d$NEWID==97882] <- 0 
blackteacherK[d$NEWID==29439] <- 1 
blackteacherK[d$NEWID==108203] <- 0 
blackteacherK[d$NEWID==7440] <- 0 
blackteacherK[d$NEWID==137152] <- 0 
blackteacherK[d$NEWID==64954] <- 0 
blackteacherK[d$NEWID==51104] <- 0 
blackteacherK[d$NEWID==5882] <- 0 
blackteacherK[d$NEWID==44778] <- 0 
blackteacherK[d$NEWID==112017] <- 0 
blackteacherK[d$NEWID==86455] <- 0 
blackteacherK[d$NEWID==4513] <- 0 

# find class sizes
matchK <- data.frame(schidkn, blackteacherK, mastersK, experienceK, smallK, regaideK)
# identify unique classes
groupK <- within(matchK, {classK <- as.numeric(factor(paste0(schidkn, blackteacherK, mastersK, experienceK, smallK, regaideK)))})
class_size <- as.vector(table(groupK$classK))
#class_size[class_size > 30]  # 3 class numbers are wrong

# reassign NAs (data will not be used)
# BSG uses slightly different numbers
groupK$classK[groupK$classK == 323] <- 901
# divide up the 3 classes (data will not be used)
groupK$classK[groupK$classK == 157 & girl == 1] <- 902
groupK$classK[groupK$classK == 242 & girl == 1] <- 903
groupK$classK[groupK$classK == 281 & girl == 1] <- 904
groupK$classK[groupK$classK == 157 & girl == 0] <- 905
groupK$classK[groupK$classK == 242 & girl == 0] <- 906
groupK$classK[groupK$classK == 281 & girl == 0] <- 907
class_size <- as.vector(table(groupK$classK))
#class_size[class_size > 30]  # only NAs left
# schools 48 (classK = 172) and 55 (202) have issues (see BSG)
groupK$classK[groupK$classK == 172] <- 908
groupK$classK[groupK$classK == 202] <- 909

# rename variables as in my paper
d$classid  <- groupK$classK
d$small    <- smallK
d$regaide  <- regaideK
d$black    <- black
d$girl     <- girl
d$poor     <- poor
d$tblack   <- blackteacherK
d$texp     <- experienceK
d$tmasters <- mastersK
d$fe       <- schidkn

remove(black, girl, poor)

# compute scores as in Krueger (1999)
# generate empirical cdfs for regular + regular/aide class
# reading
rraw <- d$TREADSSK[d$CLTYPEK > 1]
rcdf <- ecdf(rraw)
# math
mraw <- d$TMATHSSK[d$CLTYPEK > 1]
mcdf <- ecdf(mraw)
# percentile scores for all classes in reading and math
pr <- 100 * rcdf(d$TREADSSK)
pm <- 100 * mcdf(d$TMATHSSK)
# average scores per student
d$pscore <- rowMeans(cbind(pr, pm), na.rm = TRUE)

# remove all classes with data issues (317 classes left)
d <- d[d$classid < 900, ]
# remove all obs with missing pscores
#hist(table((d$classid[is.na(d$pscore)])))
#table(d$classid[is.na(d$pscore)])
#length(table(d$classid[is.na(d$pscore)]) == 1)
# 226 classes missing at least one score
# 102 are missing one, 65 missing two. At most 7 missing.
d <- d[!is.na(d$pscore), ]

write.csv(d, file = outlink)